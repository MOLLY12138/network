//
//  ViewController.swift
//  NetworkDemo
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 2016110326. All rights reserved.
//

import UIKit
import Alamofire

class ImageViewController: UIViewController {

    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func loadWithURL(_ sender: Any) {
        DispatchQueue.global().async {
            if let url = URL(string: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1545638641&di=0427bd16ca30518a05109c39e890ada1&imgtype=jpg&er=1&src=http%3A%2F%2Fimg.alicdn.com%2Fimgextra%2Fi4%2F61054549%2FTB2dri2bXXXXXaSXpXXXXXXXXXX_%21%2161054549.jpg"){
                //凡是访问网络，读文件都要加try
                if let data = try? Data(contentsOf: url){
                    DispatchQueue.main.async {
                         self.imageView1.image = UIImage(data: data)
                    }
                }
            }
        }
    }
    
    @IBAction func loadWithSession(_ sender: Any) {
    
            if let url = URL(string: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1545639899&di=f3811e160742baedf95fa17fd8b44ed5&imgtype=jpg&er=1&src=http%3A%2F%2Fimg3.duitang.com%2Fuploads%2Fitem%2F201605%2F24%2F20160524124006_2SANU.thumb.700_0.jpeg"){
                
                let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                    DispatchQueue.main.async {
                        self.imageView2.image = UIImage(data: data!)
                    }
                }
                task.resume()
            }
        
    }
    
    @IBAction func loadWithAF(_ sender: Any) {
        if let url = URL(string: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1545639899&di=f3811e160742baedf95fa17fd8b44ed5&imgtype=jpg&er=1&src=http%3A%2F%2Fimg3.duitang.com%2Fuploads%2Fitem%2F201605%2F24%2F20160524124006_2SANU.thumb.700_0.jpeg"){
            AF.request(url).responseData { (response) in
                self.imageView2.image = UIImage(data: response.data!)
            }
        }
    }
    
    
    
    
    
    
    
    
}

